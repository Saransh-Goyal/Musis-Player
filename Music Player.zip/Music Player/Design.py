from tkinter import *
from pygame import mixer
from tkinter import filedialog
from tkinter import messagebox
mixer.init()


class AppDesign:

    def __init__(self, master):
        self.song_list = []
        self.master = master

        self.main_menu = Menu()
        master.config(menu=self.main_menu)

        self.file_menu = Menu(self.main_menu, tearoff=False)
        self.main_menu.add_cascade(menu=self.file_menu, label='File')
        self.file_menu.add_command(label='New', command=self.newfile)
        self.file_menu.add_command(label='Open', command=self.openfile)
        self.file_menu.add_command(label='Exit', command=master.quit)

        # List Frame Components

        self.plusimage = PhotoImage(file='Images/Plus.png')
        self.button = Label(self.master, image=self.plusimage, bg='#34cfeb')
        self.button.place(x=200, y=242)

        self.minusimage = PhotoImage(file='Images/Minus.png')
        self.button = Label(self.master, image=self.minusimage, bg='#34cfeb')
        self.button.place(x=200, y=370)

        self.infolabel = Button(self.master, bg='#34cfeb', font='verdana 12', text='Create Playlist', fg='Black',
                                command=self.newfile, bd=0)
        self.infolabel.grid(row=0, column=0, padx=(0,30), pady=20)

        self.delete_btn = Button

        self.scroll = Scrollbar(self.master, orient=VERTICAL,width=20)
        self.listitems = Listbox(self.master, width=30, height=10, yscrollcommand=self.scroll.set)
        self.listitems.grid(row=1, column=0, padx=(20, 0))
        self.scroll.config(command=self.listitems.yview)
        self.scroll.grid(row=1, column=2, padx=(0, 30), sticky=N+S)

        self.filename = Label(self.master, text="", width=20, bg='#34cfeb')
        self.filename.place(x=25, y=350)

        self.volumebar = Scale(self.master, from_=100, to=0, orient=VERTICAL, bg='#34cfeb', command=self.set_volume,
                               length=90, sliderlength=20, width=8, cursor='Dot',
                               highlightbackground='#34cfeb', troughcolor='#34cfeb', bd=0)
        self.volumebar.set(75)
        mixer.music.set_volume(0.75)
        self.volumebar.place(x=180, y=270)

        self.play_image = PhotoImage(file='Images/play.png')
        self.play_button = Button(self.master, image=self.play_image, width=50, command=self.start_play, bg='#34cfeb', bd=0)
        self.play_button.place(x=40, y=250)

        self.pause_image = PhotoImage(file='Images/pause.png')
        self.pause_button = Button(self.master, image=self.pause_image, width=50,
                                   command=self.pause_play, bg='#34cfeb', bd=0)
        self.pause_button.place(x=110, y=250)

        self.resume_image = PhotoImage(file='Images/pause.png')
        self.resume_button = Button(self.master, image=self.resume_image, width=50, bg='red',
                                    command=self.resume_play, bd=0)
        self.resume_button.place_forget()

        self.stop_image = PhotoImage(file='Images/stop.png')
        self.stop_button = Button(self.master, image=self.stop_image, width=50, command=self.stop_play, bg='#34cfeb', bd=0)
        self.stop_button.place(x=40, y=300)

        self.repeat_image = PhotoImage(file='Images/repeat.png')
        self.repeat_button = Button(self.master, image=self.repeat_image, width=50,
                                    command=self.repeat_play, bg='#34cfeb', bd=0)
        self.repeat_button.place(x=110, y=300)

    def start_play(self):
        selected_song = self.listitems.curselection()
        print(type(selected_song))
        print(len(selected_song))
        try:
            self.resume_button.place_forget()
            if len(selected_song) == 0:
                mixer.music.load(self.song_list[0])
                index_1 = self.song_list[0].rindex('/')
                last_index_2 = self.song_list[0].rindex('.')
                y_filename = self.song_list[0][index_1 + 1:last_index_2]
                print(y_filename)
                self.filename.config(text=f' {y_filename}')
                self.listitems.select_set(0)
                mixer.music.play()
            else:
                index = selected_song[0]
                print(index)
                mixer.music.load(self.song_list[index])
                index_1 = self.song_list[0].rindex('/')
                last_index_2 = self.song_list[index].rindex('.')
                y_filename = self.song_list[index][index_1 + 1:last_index_2]
                print(y_filename)
                self.filename.config(text=y_filename)
                self.listitems.select_set(index)
                mixer.music.play()
        except IndexError:
            messagebox.showerror('Error', 'Create playlist', icon='error')

    def stop_play(self):
        mixer.music.stop()

    def pause_play(self):

        if len(self.filename.cget('text')) > 0:
            mixer.music.pause()
            self.resume_button.place(x=110, y=250)

    def resume_play(self):
        mixer.music.unpause()
        self.resume_button.place_forget()

    def repeat_play(self):
        mixer.music.rewind()

    def set_volume(self,val):
        volume = int(val)/100
        mixer.music.set_volume(volume)

    def newfile(self):
        self.pause_play()
        selected_files = filedialog.askopenfiles(initialdir='H://Avnee_Ericsson//C_Drive//PUNJABI',
                                                 title='Select the music files',
                                                 filetypes=(('mp3 Files', '*.mp3'), ('All Types', '*.*')))
        if len(selected_files) is not 0:
            self.stop_play()
            self.resume_play()
            self.listitems.delete(0, END)
            for i in range(len(selected_files)):
                x_filename = selected_files[i].name
                last_index = x_filename.rindex('/')
                last_index_2 = x_filename.rindex('.')
                y_filename = x_filename[last_index + 1:last_index_2]
                self.song_list.append(x_filename)
                self.listitems.insert(END, y_filename)
        else:
            self.resume_play()

    def openfile(self):
        self.pause_play()
        selected_files = filedialog.askopenfiles(initialdir='H://Avnee_Ericsson//C_Drive//PUNJABI',
                                                 title='Select the music files', filetypes=(('mp3 Files', '*.mp3'),
                                                                                            ('All Types', '*.*')))
        if selected_files is not None:
            for i in range(len(selected_files)):
                x_filename = selected_files[i].name
                self.song_list.append(x_filename)
                last_index = x_filename.rindex('/')
                last_index_2 = x_filename.rindex('.')
                y_filename = x_filename[last_index+1:last_index_2]
                self.listitems.insert(END, y_filename)
        self.resume_play()

